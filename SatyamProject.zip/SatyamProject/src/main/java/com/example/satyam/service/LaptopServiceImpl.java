package com.example.satyam.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.satyam.dto.Laptop;
import com.example.satyam.repository.LaptopRepository;

@Service
public class LaptopServiceImpl implements LaptopService {

	@Autowired
	private LaptopRepository laptopRepository;

	@Override
	public void saveLaptop(Laptop laptop) {
		if (laptop != null) {
			laptopRepository.save(laptop);
		}
	}

}
