package com.example.satyam.service;

import com.example.satyam.dto.Laptop;

public interface LaptopService {
	
	public void saveLaptop(Laptop laptop);

}
