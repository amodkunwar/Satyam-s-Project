package com.example.satyam.service;

import java.util.List;

import com.example.satyam.dto.Laptop;

public interface LaptopService {

	public void saveLaptop(Laptop laptop);

	public void updateLaptop(Laptop laptop, Integer laptopId) throws Exception;

	public List<Laptop> getAllLaptop();

}
