package com.example.satyam.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Laptop")
public class Laptop {

	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "laptop_id")
	private Integer laptopId;

	@Column(name = "Laptop_date_issue")
	private Date laptopDateIsuue = new Date();

	@Column(name = "Laptop_Brand")
	private String loptopBrand;

	public Laptop() {
		System.out.println(this.getClass().getSimpleName() + " created.");
	}

	public Laptop(Date laptopDateIsuue, String loptopBrand) {
		this.laptopDateIsuue = laptopDateIsuue;
		this.loptopBrand = loptopBrand;
	}

	public Integer getLaptopId() {
		return laptopId;
	}

	public void setLaptopId(Integer laptopId) {
		this.laptopId = laptopId;
	}

	public Date getLaptopDateIsuue() {
		return laptopDateIsuue;
	}

	public void setLaptopDateIsuue(Date laptopDateIsuue) {
		this.laptopDateIsuue = laptopDateIsuue;
	}

	public String getLoptopBrand() {
		return loptopBrand;
	}

	public void setLoptopBrand(String loptopBrand) {
		this.loptopBrand = loptopBrand;
	}

}
