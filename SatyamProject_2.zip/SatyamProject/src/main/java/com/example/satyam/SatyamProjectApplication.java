package com.example.satyam;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.satyam.dto.Laptop;
import com.example.satyam.repository.LaptopRepository;

@SpringBootApplication
public class SatyamProjectApplication implements ApplicationRunner {

	@Autowired
	private LaptopRepository laptopRepository;

	public static void main(String[] args) {
		SpringApplication.run(SatyamProjectApplication.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {

		// using setter and getter
		Laptop laptop = new Laptop();
		laptop.setLaptopDateIsuue(new Date());
		laptop.setLoptopBrand("Samsung");

		// using contructor
		laptopRepository.save(new Laptop(new Date(), "Asus"));
		laptopRepository.save(new Laptop(new Date(), "Hp"));
		laptopRepository.save(new Laptop(new Date(), "dell"));
		laptopRepository.save(new Laptop(new Date(), "sony"));
		laptopRepository.save(new Laptop(new Date(), "Lenovo"));

		laptopRepository.save(laptop);
	}
}
