package com.example.satyam.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.satyam.dto.Laptop;
import com.example.satyam.service.LaptopServiceImpl;

@RestController
@RequestMapping("/laptop")
public class LaptopController {

	@Autowired
	private LaptopServiceImpl laptopService;

	@PostMapping("/add")
	public ResponseEntity<String> addLaptop(@Valid @RequestBody Laptop laptop) {
		laptopService.saveLaptop(laptop);
		return new ResponseEntity<String>("Data inserted successfully", HttpStatus.OK);
	}

	@PutMapping("/update/{laptopId}")
	public ResponseEntity<String> updateLaptop(@RequestBody Laptop laptop, @PathVariable("laptopId") Integer laptopId)
			throws Exception {
		laptopService.updateLaptop(laptop, laptopId);
		return new ResponseEntity<String>("Data Updated successfully", HttpStatus.OK);
	}

	@GetMapping("/all")
	public List<Laptop> getAllLaptop() {
		return laptopService.getAllLaptop();
	}

}
