package com.example.satyam.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.satyam.dto.Laptop;
import com.example.satyam.repository.LaptopRepository;

@Service
public class LaptopServiceImpl implements LaptopService {

	@Autowired
	private LaptopRepository laptopRepository;

	@Override
	public void saveLaptop(Laptop laptop) {
		if (laptop != null) {
			laptopRepository.save(laptop);
		}
	}

	@Override
	public void updateLaptop(Laptop laptop, Integer laptopId) throws Exception {
		Optional<Laptop> findById = laptopRepository.findById(laptopId);
		if (findById == null || !findById.isPresent()) {
			throw new Exception("Id not found");
		}
		else if (findById != null && findById.isPresent()) {
			findById.get().setLoptopBrand(laptop.getLoptopBrand());
			findById.get().setLaptopDateIsuue(laptop.getLaptopDateIsuue());
			laptop.setLaptopId(laptopId);
			laptopRepository.save(laptop);
		}
	}

	@Override
	public List<Laptop> getAllLaptop() {
		List<Laptop> listLaptop = new ArrayList<>();
		laptopRepository.findAll().forEach(laptops -> listLaptop.add(laptops));
		return listLaptop;
	}

}
